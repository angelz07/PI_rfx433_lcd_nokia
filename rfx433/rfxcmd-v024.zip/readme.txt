
RFXCMD
------

The read me is now in the wiki on GoogleCode page.

http://code.google.com/p/rfxcmd/wiki/ReadMe